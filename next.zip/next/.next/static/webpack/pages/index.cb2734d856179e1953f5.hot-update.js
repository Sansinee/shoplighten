self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSG": function() { return /* binding */ __N_SSG; },
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_head_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/head/index */ "./components/head/index.js");
/* harmony import */ var _components_footer_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/footer/index */ "./components/footer/index.js");
/* harmony import */ var _components_Product_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Product/index */ "./components/Product/index.js");
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "D:\\next\\pages\\index.js";



var __N_SSG = true;
function Home(props) {
  var data = props.data;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_head_index__WEBPACK_IMPORTED_MODULE_1__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 81,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Product_index__WEBPACK_IMPORTED_MODULE_3__.default, {
      data: data
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 82,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_footer_index__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 83,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}
_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiSG9tZSIsInByb3BzIiwiZGF0YSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7O0FBMEVlLFNBQVNBLElBQVQsQ0FBY0MsS0FBZCxFQUFxQjtBQUFBLE1BQzFCQyxJQUQwQixHQUNqQkQsS0FEaUIsQ0FDMUJDLElBRDBCO0FBRWxDLHNCQUNFO0FBQUEsNEJBQ0UsOERBQUMsMkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUUsOERBQUMsOERBQUQ7QUFBUyxVQUFJLEVBQUVBO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBR0UsOERBQUMsNkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUhGO0FBQUEsa0JBREY7QUFPRDtLQVR1QkYsSSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5jYjI3MzRkODU2MTc5ZTE5NTNmNS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFNldEhlYWQgZnJvbSBcIi4uL2NvbXBvbmVudHMvaGVhZC9pbmRleFwiO1xuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi4vY29tcG9uZW50cy9mb290ZXIvaW5kZXhcIjtcbmltcG9ydCBQcm9kdWN0IGZyb20gXCIuLi9jb21wb25lbnRzL1Byb2R1Y3QvaW5kZXhcIjtcblxuY29uc3QgRFVNTVlfTUVFVFVQUyA9IFtcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDEsXG4gICAgcHJvZHVjdF9uYW1lOiBcIkxJU0EgUEhPVE9CT09LIFswMzI3XSAtTElNSVRFRCBFRElUSU9OLVwiLFxuICAgIGltYWdlX3BhdGg6IFwiaHR0cHM6Ly9mLmJ0d2Nkbi5jb20vc3RvcmUtNDc0NjMvcHJvZHVjdC10aHVtYi83YTI0NzY2ZC0yNmRhLTZlNmItZDdlOS02MDA5NmY5MWVkZTUuanBnXCIsXG4gICAgcHJpY2U6IDk1MCxcbiAgfSxcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDIsXG4gICAgcHJvZHVjdF9uYW1lOiBcIkxJU0EgUEhPVE9CT09LIFswMzI3XSBWT0wuMiAtU0VDT05EIEVESVRJT04tXCIsXG4gICAgaW1hZ2VfcGF0aDogXCJodHRwczovL2YuYnR3Y2RuLmNvbS9zdG9yZS00NzQ2My9wcm9kdWN0L2EyOWRhMTkwLTg2NjUtZTI0Ni02NDE5LTYwNTFkNTJmZDhkYS5qcGdcIixcbiAgICBwcmljZTogMTA1MCxcbiAgfSxcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDMsXG4gICAgcHJvZHVjdF9uYW1lOiBcIlJvc8OpIEZpcnN0IFNpbmdsZSBBbGJ1bSAtIFIgLSBLaXQgQWxidW1cIixcbiAgICBpbWFnZV9wYXRoOiBcImh0dHBzOi8vZi5idHdjZG4uY29tL3N0b3JlLTQ3NDYzL3Byb2R1Y3QvY2JjMWM0OWMtMDIwMS0xYjUzLTg0Y2QtNjA2MDA4NWEyNGZmLmpwZ1wiLFxuICAgIHByaWNlOiA3NTAuMDAsXG4gIH0sXG4gIHtcbiAgICBwcm9kdWN0X2lkOiA0LFxuXG4gICAgcHJvZHVjdF9uYW1lOiBcIlJPU8OJIFBIT1RPIENBUkQgKyBTVElDS0VSIFNFVFwiLFxuICAgIGltYWdlX3BhdGg6IFwiaHR0cHM6Ly9mLmJ0d2Nkbi5jb20vc3RvcmUtNDc0NjMvcHJvZHVjdC84N2I5MmFhZC0wMTE0LTdlOGEtZDA4Ny02MDc5M2NmOGFiM2IuanBnXCIsXG4gICAgcHJpY2U6IDM1MCxcbiAgfSxcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDUsXG5cbiAgICBwcm9kdWN0X25hbWU6IFwiRHluYW1pdGUgQ0RcIixcbiAgICBpbWFnZV9wYXRoOlwiaHR0cHM6Ly9kMmo2ZGJxMGV1eDBiZy5jbG91ZGZyb250Lm5ldC9pbWFnZXMvNTQ1NjQwNTkvMjIzODI2MzgxNS5qcGdcIixcbiAgICBwcmljZTogOTUwLFxuICB9LFxuICB7XG4gICAgcHJvZHVjdF9pZDogNixcblxuICAgIHByb2R1Y3RfbmFtZTogXCJCVFMgTUFQIG9mIFRIRSBTT1VMOiA3XCIsXG4gICAgaW1hZ2VfcGF0aDpcImh0dHBzOi8vZHVkZXBsYWNlLmNvL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDIwLzAyL3E2MzEzdWlxOGRna2E1N3poaTUtbzE0NzY2MDQ4NDEyMzk4Mjg0OS5qcGdcIixcbiAgICBwcmljZTogMTQwMCxcbiAgfSxcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDcsXG5cbiAgICBwcm9kdWN0X25hbWU6IFwiQlRTIC0gTG92ZSBZb3Vyc2VsZiBUZWFyXCIsXG4gICAgaW1hZ2VfcGF0aDogXCJodHRwczovL3RoLXRlc3QtMTEuc2xhdGljLm5ldC9wLzY1ZWIyYzIxYzdlMmIzZWNjMDA3MGRjZjA2MmFlYjkzLmpwZ1wiLFxuXG4gICAgcHJpY2U6IDExODAsXG4gIH0sXG4gIHtcbiAgICBwcm9kdWN0X2lkOiA4LFxuXG4gICAgcHJvZHVjdF9uYW1lOiBcIkJUUyAtIEJFIChFc3NlbnRpYWwgRWRpdGlvbilcIixcbiAgICBpbWFnZV9wYXRoOiBcImh0dHBzOi8vbC5sbndmaWxlLmNvbS9lcDlkZ3guanBnXCIsXG4gICAgcHJpY2U6IDEyMzAsXG4gIH0sXG4gIHtcbiAgICBwcm9kdWN0X2lkOiA5LFxuXG4gICAgcHJvZHVjdF9uYW1lOiBcIkJhYnkgQlQyMSBCb3VjbGUgU2xpcHBlcnNcIixcbiAgICBpbWFnZV9wYXRoOlxuICAgICAgXCJodHRwczovL2QyajZkYnEwZXV4MGJnLmNsb3VkZnJvbnQubmV0L2ltYWdlcy81NDU2NDA1OS8yMTU4MzI3MDc5LmpwZ1wiLFxuICAgIHByaWNlOiA3NDUsXG4gIH0sXG4gIHtcbiAgICBwcm9kdWN0X2lkOiAxMCxcbiAgICBwcm9kdWN0X25hbWU6IFwiQlQyMSAnQSBEcmVhbSBvZiBCYWJ5J1wiLFxuICAgIGltYWdlX3BhdGg6XG4gICAgICBcImh0dHBzOi8vZDJqNmRicTBldXgwYmcuY2xvdWRmcm9udC5uZXQvaW1hZ2VzLzU0NTY0MDU5LzIxNDIwODQxMTMuanBnXCIsXG4gICAgcHJpY2U6IDIxNzAsXG4gIH0sXG5dO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKHByb3BzKSB7XG4gIGNvbnN0IHsgZGF0YSB9ID0gcHJvcHM7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxTZXRIZWFkIC8+XG4gICAgICA8UHJvZHVjdCBkYXRhPXtkYXRhfSAvPlxuICAgICAgPEZvb3RlciAvPlxuICAgIDwvPlxuICApO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGljUHJvcHMoKSB7XG4gIC8vIGZldGNoIGRhdGEgZnJvbSBhbiBBUElcbiAgcmV0dXJuIHtcbiAgICBwcm9wczoge1xuICAgICAgZGF0YTogRFVNTVlfTUVFVFVQUyxcbiAgICB9LFxuICB9O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==