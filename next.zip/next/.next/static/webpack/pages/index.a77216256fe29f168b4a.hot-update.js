self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSG": function() { return /* binding */ __N_SSG; },
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_head_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/head/index */ "./components/head/index.js");
/* harmony import */ var _components_footer_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/footer/index */ "./components/footer/index.js");
/* harmony import */ var _components_Product_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Product/index */ "./components/Product/index.js");
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "D:\\next\\pages\\index.js";



var __N_SSG = true;
function Home(props) {
  var data = props.data;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_head_index__WEBPACK_IMPORTED_MODULE_1__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 81,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Product_index__WEBPACK_IMPORTED_MODULE_3__.default, {
      data: data
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 82,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_footer_index__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 83,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}
_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiSG9tZSIsInByb3BzIiwiZGF0YSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7O0FBMEVlLFNBQVNBLElBQVQsQ0FBY0MsS0FBZCxFQUFxQjtBQUFBLE1BQzFCQyxJQUQwQixHQUNqQkQsS0FEaUIsQ0FDMUJDLElBRDBCO0FBRWxDLHNCQUNFO0FBQUEsNEJBQ0UsOERBQUMsMkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUUsOERBQUMsOERBQUQ7QUFBUyxVQUFJLEVBQUVBO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBR0UsOERBQUMsNkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUhGO0FBQUEsa0JBREY7QUFPRDtLQVR1QkYsSSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5hNzcyMTYyNTZmZTI5ZjE2OGI0YS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFNldEhlYWQgZnJvbSBcIi4uL2NvbXBvbmVudHMvaGVhZC9pbmRleFwiO1xuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi4vY29tcG9uZW50cy9mb290ZXIvaW5kZXhcIjtcbmltcG9ydCBQcm9kdWN0IGZyb20gXCIuLi9jb21wb25lbnRzL1Byb2R1Y3QvaW5kZXhcIjtcblxuY29uc3QgRFVNTVlfTUVFVFVQUyA9IFtcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDEsXG4gICAgcHJvZHVjdF9uYW1lOiBcIk5vcnRvbiBJbnRlcm5ldCBTZWN1cml0eSAxXCIsXG4gICAgaW1hZ2VfcGF0aDogXCJpY29uL3AxLnBuZ1wiLFxuICAgIHByaWNlOiA5NTAsXG4gIH0sXG4gIHtcbiAgICBwcm9kdWN0X2lkOiAyLFxuICAgIHByb2R1Y3RfbmFtZTogXCJOb3J0b24gSW50ZXJuZXQgU2VjdXJpdHkgMlwiLFxuICAgIGltYWdlX3BhdGg6IFwiaWNvbi9wMi5wbmdcIixcbiAgICBwcmljZTogMTA1MCxcbiAgfSxcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDMsXG4gICAgcHJvZHVjdF9uYW1lOiBcIk5vcnRvbiBJbnRlcm5ldCBTZWN1cml0eSAzXCIsXG4gICAgaW1hZ2VfcGF0aDogXCJpY29uL3AzLnBuZ1wiLFxuICAgIHByaWNlOiA3NTAuMDAsXG4gIH0sXG4gIHtcbiAgICBwcm9kdWN0X2lkOiA0LFxuXG4gICAgcHJvZHVjdF9uYW1lOiBcIk5vcnRvbiBJbnRlcm5ldCBTZWN1cml0eSA0XCIsXG4gICAgaW1hZ2VfcGF0aDogXCJpY29uL3A0LnBuZ1wiLFxuICAgIHByaWNlOiAzNTAsXG4gIH0sXG4gIHtcbiAgICBwcm9kdWN0X2lkOiA1LFxuXG4gICAgcHJvZHVjdF9uYW1lOiBcIk5vcnRvbiBJbnRlcm5ldCBTZWN1cml0eSA1XCIsXG4gICAgaW1hZ2VfcGF0aDpcImljb24vcDUucG5nXCIsXG4gICAgcHJpY2U6IDk1MCxcbiAgfSxcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDYsXG5cbiAgICBwcm9kdWN0X25hbWU6IFwiTm9ydG9uIEludGVybmV0IFNlY3VyaXR5IDZcIixcbiAgICBpbWFnZV9wYXRoOlwiaWNvbi9wNi5wbmdcIixcbiAgICBwcmljZTogMTQwMCxcbiAgfSxcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDcsXG5cbiAgICBwcm9kdWN0X25hbWU6IFwiTm9ydG9uIEludGVybmV0IFNlY3VyaXR5IDdcIixcbiAgICBpbWFnZV9wYXRoOiBcImljb24vcDcucG5nXCIsXG5cbiAgICBwcmljZTogMTE4MCxcbiAgfSxcbiAge1xuICAgIHByb2R1Y3RfaWQ6IDgsXG5cbiAgICBwcm9kdWN0X25hbWU6IFwiTm9ydG9uIEludGVybmV0IFNlY3VyaXR5IDhcIixcbiAgICBpbWFnZV9wYXRoOiBcImljb24vcDIucG5nXCIsXG4gICAgcHJpY2U6IDEyMzAsXG4gIH0sXG4gIHtcbiAgICBwcm9kdWN0X2lkOiA5LFxuXG4gICAgcHJvZHVjdF9uYW1lOiBcIk5vcnRvbiBJbnRlcm5ldCBTZWN1cml0eSA5XCIsXG4gICAgaW1hZ2VfcGF0aDpcbiAgICAgIFwiaWNvbi9wNS5wbmdcIixcbiAgICBwcmljZTogNzQ1LFxuICB9LFxuICB7XG4gICAgcHJvZHVjdF9pZDogMTAsXG4gICAgcHJvZHVjdF9uYW1lOiBcIk5vcnRvbiBJbnRlcm5ldCBTZWN1cml0eSAxMFwiLFxuICAgIGltYWdlX3BhdGg6XG4gICAgICBcImljb24vcDEucG5nXCIsXG4gICAgcHJpY2U6IDIxNzAsXG4gIH0sXG5dO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKHByb3BzKSB7XG4gIGNvbnN0IHsgZGF0YSB9ID0gcHJvcHM7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxTZXRIZWFkIC8+XG4gICAgICA8UHJvZHVjdCBkYXRhPXtkYXRhfSAvPlxuICAgICAgPEZvb3RlciAvPlxuICAgIDwvPlxuICApO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGljUHJvcHMoKSB7XG4gIC8vIGZldGNoIGRhdGEgZnJvbSBhbiBBUElcbiAgcmV0dXJuIHtcbiAgICBwcm9wczoge1xuICAgICAgZGF0YTogRFVNTVlfTUVFVFVQUyxcbiAgICB9LFxuICB9O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==